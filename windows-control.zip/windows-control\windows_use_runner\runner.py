from __future__ import annotations

import argparse
import base64
import json
import os
import re
import subprocess
import sys
import time
from io import BytesIO
from pathlib import Path
from typing import Any

import google.generativeai as genai
import pyautogui
import requests
from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")
pyautogui.FAILSAFE = True
pyautogui.PAUSE = float(os.environ.get("JARVIS_COMPUTER_USE_ACTION_DELAY", "0.08"))


def _json_error(message: str, *, code: str = "COMPUTER_USE_FAILED", details: Any = None) -> int:
    print(json.dumps({"ok": False, "code": code, "error": message, "details": details}, ensure_ascii=True))
    return 1


def screenshot_b64() -> tuple[str, dict[str, int]]:
    image = pyautogui.screenshot()
    stream = BytesIO()
    image.save(stream, format="PNG")
    width, height = image.size
    return base64.b64encode(stream.getvalue()).decode("ascii"), {"width": width, "height": height}


def parse_screen(image_b64: str) -> dict[str, Any]:
    url = os.environ.get("JARVIS_VISUAL_PARSER_URL", "http://127.0.0.1:7860/parse")
    try:
        response = requests.post(url, json={"screenshotBase64": image_b64}, timeout=12)
        response.raise_for_status()
        return response.json()
    except Exception as exc:
        return {"mode": "visual_parser_unavailable", "error": str(exc), "elements": []}


def summarize_elements(parsed: dict[str, Any], limit: int = 80) -> str:
    elements = parsed.get("elements")
    if not isinstance(elements, list):
        return ""
    rows: list[str] = []
    for item in elements[:limit]:
        if not isinstance(item, dict):
            continue
        center = item.get("center") if isinstance(item.get("center"), dict) else {}
        text = str(item.get("text") or "").replace("\n", " ").strip()
        kind = str(item.get("kind") or "element")
        eid = str(item.get("id") or "")
        conf = item.get("confidence", "")
        if not text and kind == "region":
            continue
        rows.append(f'{eid} {kind} "{text[:90]}" center=({center.get("x","?")},{center.get("y","?")}) conf={conf}')
    return "\n".join(rows)


def make_model() -> Any:
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY missing hai.")
    genai.configure(api_key=api_key)
    model_name = os.environ.get("JARVIS_COMPUTER_USE_MODEL") or os.environ.get("GEMINI_MODEL") or "gemini-2.5-flash-lite"
    return genai.GenerativeModel(model_name), model_name


def plan_action(model: Any, task: str, parsed: dict[str, Any], screen: dict[str, int], history: list[dict[str, Any]], language: str) -> dict[str, Any]:
    elements = summarize_elements(parsed)
    prompt = f"""
You are Jarvis Computer Use, controlling the user's Windows computer.

You receive the user task, screen size, visual-parser text/elements from the latest screenshot, and recent action history.
Choose exactly ONE next action. Return only valid JSON. No markdown.

Use these tools:
- open_app: {{"action":"open_app","app":"terminal|powershell|cmd|notepad|calculator|explorer|paint|settings|<app name>"}}
- run_powershell: {{"action":"run_powershell","command":"safe PowerShell command"}}
- click: {{"action":"click","x":123,"y":456,"button":"left","double":false}}
- type: {{"action":"type","text":"text to type"}}
- hotkey: {{"action":"hotkey","keys":["ctrl","l"]}}
- press: {{"action":"press","key":"enter"}}
- scroll: {{"action":"scroll","amount":-5}}  // negative scrolls down, positive scrolls up
- wait: {{"action":"wait","ms":1000}}
- done: {{"action":"done","message":"final user-facing message"}}
- need_user: {{"action":"need_user","message":"what the user must do manually"}}

Routing and safety:
- This is NOT browser-use. Do not open Chrome/browser unless the user explicitly asked for a website/browser/URL.
- For "terminal kholo", "टर्मिनल खोल", PowerShell, CMD, or command prompt: use open_app with terminal/powershell/cmd.
- For local files/folders/settings/apps/window control, use Windows tools here.
- Do not delete/overwrite/change security/payment/password settings unless the user clearly requested it.
- If a password, OTP, captcha, or privileged security prompt appears, return need_user.
- If the task is already complete in the current screen/history, return done.
- Prefer open_app/run_powershell for app launching and file operations. Prefer click/type only for visible UI work.
- Use visual-parser centers for clicks when needed.
- In Hindi mode, messages must be natural Hinglish/Hindi and address the user as boss.

Language mode: {language}
Screen: {screen}
User task: {task}

Visual parser:
{elements or "(no parser elements available)"}

Recent history:
{json.dumps(history[-8:], ensure_ascii=False)}
"""
    response = model.generate_content(prompt, generation_config={"temperature": 0.1})
    text = (getattr(response, "text", "") or "").strip()
    return json.loads(strip_json_fence(text))


def run_action(action: dict[str, Any]) -> dict[str, Any]:
    name = str(action.get("action") or "").strip()
    if name == "open_app":
        app = str(action.get("app") or "").strip()
        open_app(app)
        return {"ok": True, "action": "open_app", "app": app}
    if name == "run_powershell":
        command = str(action.get("command") or "").strip()
        if not command:
            raise RuntimeError("PowerShell command missing.")
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            timeout=int(os.environ.get("JARVIS_COMPUTER_USE_SHELL_TIMEOUT", "30")),
        )
        return {"ok": completed.returncode == 0, "action": "run_powershell", "stdout": completed.stdout[-1000:], "stderr": completed.stderr[-1000:]}
    if name == "click":
        x = int(action.get("x"))
        y = int(action.get("y"))
        button = str(action.get("button") or "left")
        double = bool(action.get("double", False))
        pyautogui.click(x=x, y=y, button=button, clicks=2 if double else 1, interval=0.08)
        return {"ok": True, "action": "click", "x": x, "y": y}
    if name == "type":
        text = str(action.get("text") or "")
        pyautogui.write(text, interval=float(os.environ.get("JARVIS_COMPUTER_USE_TYPE_INTERVAL", "0.01")))
        return {"ok": True, "action": "type", "chars": len(text)}
    if name == "hotkey":
        keys = action.get("keys")
        if not isinstance(keys, list) or not keys:
            raise RuntimeError("hotkey keys missing.")
        pyautogui.hotkey(*[str(key) for key in keys])
        return {"ok": True, "action": "hotkey", "keys": keys}
    if name == "press":
        key = str(action.get("key") or "")
        if not key:
            raise RuntimeError("press key missing.")
        pyautogui.press(key)
        return {"ok": True, "action": "press", "key": key}
    if name == "scroll":
        amount = int(action.get("amount", 0))
        pyautogui.scroll(amount)
        return {"ok": True, "action": "scroll", "amount": amount}
    if name == "wait":
        ms = int(action.get("ms", 1000))
        time.sleep(max(0, min(ms, 30000)) / 1000)
        return {"ok": True, "action": "wait", "ms": ms}
    if name in {"done", "need_user"}:
        return {"ok": True, "action": name, "message": str(action.get("message") or "")}
    raise RuntimeError(f"Unknown computer-use action: {name}")


def open_app(app: str) -> None:
    normalized = app.lower().strip()
    commands = {
        "terminal": "wt.exe",
        "windows terminal": "wt.exe",
        "powershell": "powershell.exe",
        "cmd": "cmd.exe",
        "command prompt": "cmd.exe",
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "explorer": "explorer.exe",
        "file explorer": "explorer.exe",
        "paint": "mspaint.exe",
        "settings": "ms-settings:",
    }
    command = commands.get(normalized, app)
    try:
        if command.endswith(":"):
            subprocess.Popen(["cmd.exe", "/c", "start", "", command], shell=False)
        else:
            subprocess.Popen(command, shell=True)
    except Exception:
        subprocess.Popen(["powershell.exe", "-NoProfile", "-Command", f"Start-Process {ps_quote(command)}"])
    time.sleep(1.2)


def invoke(task: str, max_steps: int) -> dict[str, Any]:
    model, model_name = make_model()
    language = "hi" if os.environ.get("JARVIS_LANGUAGE", "hi").lower().startswith("hi") else "en"
    history: list[dict[str, Any]] = []

    for step in range(1, max_steps + 1):
        image_b64, screen = screenshot_b64()
        parsed = parse_screen(image_b64)
        action = plan_action(model, task, parsed, screen, history, language)
        result = run_action(action)
        history.append({"step": step, "planned": action, "result": result})
        if result.get("action") == "done":
            return final(True, model_name, history, str(result.get("message") or done_message(language)))
        if result.get("action") == "need_user":
            return final(False, model_name, history, str(result.get("message") or "Need user action."))
        time.sleep(float(os.environ.get("JARVIS_COMPUTER_USE_OBSERVE_DELAY", "0.6")))

    return final(False, model_name, history, "Boss, step limit aa gayi. Is task ko chhote parts me boliye.")


def final(success: bool, model: str, history: list[dict[str, Any]], message: str) -> dict[str, Any]:
    return {
        "ok": success,
        "engine": "computer-use",
        "provider": "gemini",
        "model": model,
        "done": success,
        "successful": success,
        "steps": len(history),
        "finalResult": message,
        "actions": [item["planned"].get("action") for item in history if isinstance(item.get("planned"), dict)],
        "history": history[-5:],
    }


def done_message(language: str) -> str:
    return "Ho gaya boss, kaam complete kar diya." if language == "hi" else "Done boss, task completed."


def strip_json_fence(text: str) -> str:
    text = re.sub(r"^```json\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"^```\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text.strip())
    return text.strip()


def ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def main() -> int:
    parser = argparse.ArgumentParser(description="Jarvis computer-use runner")
    parser.add_argument("--task", required=True)
    parser.add_argument("--max-steps", type=int, default=int(os.environ.get("JARVIS_COMPUTER_USE_MAX_STEPS", os.environ.get("JARVIS_WINDOWS_USE_MAX_STEPS", "25"))))
    args = parser.parse_args()

    try:
        result = invoke(args.task, args.max_steps)
    except Exception as error:
        return _json_error(str(error), details=type(error).__name__)

    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
