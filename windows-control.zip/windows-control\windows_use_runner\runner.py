from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")


def _json_error(message: str, *, code: str = "WINDOWS_USE_FAILED", details: Any = None) -> int:
    print(json.dumps({"ok": False, "code": code, "error": message, "details": details}, ensure_ascii=True))
    return 1


def _browser_choice() -> Any:
    from windows_use import Browser

    value = os.environ.get("JARVIS_WINDOWS_USE_BROWSER", "chrome").lower()
    if value.startswith("edge"):
        return Browser.EDGE
    if value.startswith("firefox"):
        return Browser.FIREFOX
    return Browser.CHROME


def _result_text(result: Any) -> str:
    if isinstance(result, str):
        return result
    content = getattr(result, "content", None)
    if isinstance(content, str):
        return content
    answer = getattr(result, "answer", None)
    if isinstance(answer, str):
        return answer
    return str(result)


def _invoke(task: str, max_steps: int) -> dict[str, Any]:
    from windows_use import Agent
    from windows_use.providers.google import ChatGoogle

    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY missing hai.")

    model = os.environ.get("JARVIS_WINDOWS_USE_MODEL") or os.environ.get("GEMINI_MODEL") or "gemini-2.5-flash"
    language = os.environ.get("JARVIS_LANGUAGE", "hi").lower()
    instructions = [
        "You are Jarvis Windows-control specialist.",
        "Use Windows accessibility tree and real GUI actions.",
        "Ask before destructive delete/overwrite/system-changing actions unless the user explicitly requested them.",
        "Stop for passwords, OTP, payment, captcha, or security prompts.",
        "Complete the task, then stop immediately.",
    ]
    if language.startswith("hi"):
        instructions.append("All user-facing responses must be natural energetic Hindi/Hinglish and address the user as boss.")
    else:
        instructions.append("All user-facing responses must be clear English.")

    llm = ChatGoogle(model=model, api_key=api_key)
    agent = Agent(
        llm=llm,
        browser=_browser_choice(),
        mode=os.environ.get("JARVIS_WINDOWS_USE_MODE", "flash"),
        use_vision=os.environ.get("JARVIS_WINDOWS_USE_VISION", "false").lower() == "true",
        use_accessibility=True,
        use_annotation=os.environ.get("JARVIS_WINDOWS_USE_ANNOTATION", "false").lower() == "true",
        auto_minimize=False,
        max_steps=max_steps,
        max_consecutive_failures=int(os.environ.get("JARVIS_WINDOWS_USE_MAX_FAILURES", "3")),
        instructions=instructions,
        log_to_console=True,
        log_to_file=False,
        experimental=os.environ.get("JARVIS_WINDOWS_USE_EXPERIMENTAL", "true").lower() == "true",
    )
    result = agent.invoke(task=task)
    text = _result_text(result)
    return {
        "ok": True,
        "engine": "windows-use",
        "provider": "gemini",
        "model": model,
        "done": True,
        "successful": True,
        "finalResult": text,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Jarvis windows-use runner")
    parser.add_argument("--task", required=True)
    parser.add_argument("--max-steps", type=int, default=int(os.environ.get("JARVIS_WINDOWS_USE_MAX_STEPS", "25")))
    args = parser.parse_args()

    try:
        result = _invoke(args.task, args.max_steps)
    except Exception as error:
        return _json_error(str(error), details=type(error).__name__)

    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
