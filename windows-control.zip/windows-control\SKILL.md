---
name: windows-control
description: Control Windows desktop apps, files, windows, settings, keyboard, mouse, PowerShell, and GUI workflows through CursorTouch Windows-Use. Use when Jarvis needs to operate non-browser Windows tasks such as opening apps, editing files, copying/moving/zipping folders, changing settings, resizing windows, running PowerShell, or using installed applications.
---

# Windows Control

Use this skill for Windows OS and desktop application control.

Primary engine:
- CursorTouch Windows-Use: https://github.com/CursorTouch/Windows-Use
- Python package: `windows-use`
- Provider: Gemini via `windows_use.providers.google.ChatGoogle`

Operational rules:
- Prefer Windows accessibility/UI automation over screenshot guessing.
- Ask before destructive actions unless the user clearly requested delete/overwrite/system changes.
- Stop for passwords, payment, OTP, or security prompts.
- Keep user-facing replies in Jarvis language mode.

Jarvis action:
- `windowsUse.run` with params `{"task":"clear Windows desktop task","maxSteps":25}`.
