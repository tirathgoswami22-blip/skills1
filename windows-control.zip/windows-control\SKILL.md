---
name: windows-control
description: Control Windows desktop apps, files, windows, settings, keyboard, mouse, PowerShell, and GUI workflows through Jarvis's own desktop-control engine using multi-monitor screen capture, active-window detection, visual parser/OCR/YOLO, Gemini JSON planning, safety checks, memory/state, PyAutoGUI, and PowerShell. Use when Jarvis needs to operate non-browser Windows tasks such as opening apps, editing files, copying/moving/zipping folders, changing settings, resizing windows, running PowerShell, terminal/CMD, or installed applications.
---

# Windows Control

Use this skill for Windows OS and desktop application control.

Primary engine:
- Jarvis manual Windows-control: screen capture -> active window + monitor state -> visual parser/OCR/YOLO -> UI state -> Gemini JSON action -> safety -> PyAutoGUI/PowerShell executor
- Provider: Gemini
- Actions: open app, run PowerShell, move, click, right click, double click, drag/drop, type, hotkey, press, scroll, wait, done, need_user

Operational rules:
- Prefer deterministic app launching and PowerShell for local system/file tasks.
- Use parser element centers for UI clicks and refresh screen state after each action.
- Ask before destructive actions unless the user clearly requested delete/overwrite/system changes.
- Stop for passwords, payment, OTP, or security prompts.
- Keep user-facing replies in Jarvis language mode.

Jarvis action:
- `windowsControl.run` with params `{"task":"clear Windows desktop task","maxSteps":25}`.
