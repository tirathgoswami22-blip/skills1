---
name: windows-control
description: Control Windows desktop apps, files, windows, settings, keyboard, mouse, PowerShell, and GUI workflows through a Computer Use loop using screenshot parsing, Gemini JSON planning, PyAutoGUI, and PowerShell. Use when Jarvis needs to operate non-browser Windows tasks such as opening apps, editing files, copying/moving/zipping folders, changing settings, resizing windows, running PowerShell, terminal/CMD, or installed applications.
---

# Windows Control

Use this skill for Windows OS and desktop application control.

Primary engine:
- Computer Use loop: screenshot -> visual parser -> Gemini JSON action -> PyAutoGUI/PowerShell
- Provider: Gemini
- Actions: open app, run PowerShell, click, type, hotkey, press, scroll, wait, done, need_user

Operational rules:
- Prefer Windows accessibility/UI automation over screenshot guessing.
- Ask before destructive actions unless the user clearly requested delete/overwrite/system changes.
- Stop for passwords, payment, OTP, or security prompts.
- Keep user-facing replies in Jarvis language mode.

Jarvis action:
- `windowsUse.run` with params `{"task":"clear Windows desktop task","maxSteps":25}`.
