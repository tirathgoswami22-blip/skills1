from __future__ import annotations

import argparse
import base64
import json
import os
import re
import subprocess
import sys
import time
import warnings
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

import pyautogui
import requests
from dotenv import load_dotenv
from PIL import Image

try:
    import mss
except Exception:
    mss = None


ROOT = Path(__file__).resolve().parents[1]
STATE_DIR = ROOT / ".jarvis" / "desktop-control"
MEMORY_PATH = STATE_DIR / "memory.json"

load_dotenv(ROOT / ".env")
os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")
pyautogui.FAILSAFE = True
pyautogui.PAUSE = float(os.environ.get("JARVIS_DESKTOP_ACTION_DELAY", "0.08"))


@dataclass
class Capture:
    base64_png: str
    bounds: dict[str, int]
    monitors: list[dict[str, int]]
    active_window: dict[str, Any]


def _json_error(message: str, *, code: str = "JARVIS_DESKTOP_FAILED", details: Any = None) -> int:
    print(json.dumps({"ok": False, "code": code, "error": message, "details": details}, ensure_ascii=True))
    return 1


def load_memory() -> dict[str, Any]:
    try:
        return json.loads(MEMORY_PATH.read_text("utf-8"))
    except Exception:
        return {"last_app": "", "last_task": "", "notes": []}


def save_memory(memory: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MEMORY_PATH.write_text(json.dumps(memory, ensure_ascii=False, indent=2), "utf-8")


def active_window_info() -> dict[str, Any]:
    script = r"""
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class WinInfo {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
}
public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
"@
$h = [WinInfo]::GetForegroundWindow()
$sb = New-Object System.Text.StringBuilder 1024
[WinInfo]::GetWindowText($h, $sb, $sb.Capacity) | Out-Null
$pidValue = 0
[WinInfo]::GetWindowThreadProcessId($h, [ref]$pidValue) | Out-Null
$rect = New-Object RECT
[WinInfo]::GetWindowRect($h, [ref]$rect) | Out-Null
$proc = Get-Process -Id $pidValue -ErrorAction SilentlyContinue
@{
  title = $sb.ToString()
  process = if ($proc) { $proc.ProcessName } else { "" }
  pid = $pidValue
  bounds = @{
    left = $rect.Left
    top = $rect.Top
    width = [Math]::Max(0, $rect.Right - $rect.Left)
    height = [Math]::Max(0, $rect.Bottom - $rect.Top)
  }
} | ConvertTo-Json -Compress
"""
    try:
        raw = subprocess.check_output(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], text=True, timeout=5)
        return json.loads(raw.strip())
    except Exception as exc:
        return {"title": "", "process": "", "pid": 0, "bounds": {}, "error": str(exc)}


def capture_screen() -> Capture:
    active = active_window_info()
    scope = os.environ.get("JARVIS_DESKTOP_CAPTURE_SCOPE", "all").lower()
    monitors: list[dict[str, int]] = []

    if mss is not None:
        mss_factory = getattr(mss, "MSS", None) or getattr(mss, "mss")
        with mss_factory() as sct:
            for mon in sct.monitors[1:]:
                monitors.append({"left": mon["left"], "top": mon["top"], "width": mon["width"], "height": mon["height"]})
            target = sct.monitors[0]
            if scope == "active-window":
                bounds = active.get("bounds") if isinstance(active.get("bounds"), dict) else {}
                if bounds.get("width", 0) > 50 and bounds.get("height", 0) > 50:
                    target = {"left": int(bounds["left"]), "top": int(bounds["top"]), "width": int(bounds["width"]), "height": int(bounds["height"])}
            shot = sct.grab(target)
            image = Image.frombytes("RGB", shot.size, shot.rgb)
            bounds = {"left": target["left"], "top": target["top"], "width": target["width"], "height": target["height"]}
    else:
        image = pyautogui.screenshot()
        width, height = image.size
        bounds = {"left": 0, "top": 0, "width": width, "height": height}
        monitors = [bounds]

    stream = BytesIO()
    image.save(stream, format="PNG")
    return Capture(base64.b64encode(stream.getvalue()).decode("ascii"), bounds, monitors, active)


def parse_screen(image_b64: str) -> dict[str, Any]:
    url = os.environ.get("JARVIS_VISUAL_PARSER_URL", "http://127.0.0.1:7860/parse")
    try:
        response = requests.post(url, json={"screenshotBase64": image_b64}, timeout=12)
        response.raise_for_status()
        return response.json()
    except Exception as exc:
        return {"mode": "visual_parser_unavailable", "error": str(exc), "elements": []}


def summarize_elements(parsed: dict[str, Any], limit: int = 120) -> tuple[str, str]:
    elements = parsed.get("elements")
    if not isinstance(elements, list):
        return "", ""
    rows: list[str] = []
    text_parts: list[str] = []
    for item in elements[:limit]:
        if not isinstance(item, dict):
            continue
        center = item.get("center") if isinstance(item.get("center"), dict) else {}
        text = str(item.get("text") or "").replace("\n", " ").strip()
        kind = str(item.get("kind") or "element")
        eid = str(item.get("id") or "")
        conf = item.get("confidence", "")
        if text:
            text_parts.append(text)
        if not text and kind == "region":
            continue
        rows.append(f'{eid} {kind} "{text[:90]}" center=({center.get("x","?")},{center.get("y","?")}) conf={conf}')
    return "\n".join(rows), " ".join(text_parts[:80])


def build_state(capture: Capture, parsed: dict[str, Any], history: list[dict[str, Any]], memory: dict[str, Any]) -> dict[str, Any]:
    elements, visible_text = summarize_elements(parsed)
    app = str(capture.active_window.get("process") or "")
    title = str(capture.active_window.get("title") or "")
    return {
        "capture": {
            "bounds": capture.bounds,
            "monitors": capture.monitors,
            "coordinate_rule": "element centers are screenshot-relative; executor adds capture.bounds.left/top before screen clicks",
        },
        "active_window": capture.active_window,
        "current_app_guess": app,
        "current_title_guess": title,
        "visible_text": visible_text[:3000],
        "elements": elements,
        "recent_actions": history[-8:],
        "memory": memory,
    }


def plan_action(model: Any, task: str, state: dict[str, Any], language: str) -> dict[str, Any]:
    prompt = f"""
You are Jarvis Manual Windows Control, a private Windows automation engine made for this Jarvis.

You do NOT use external desktop-control libraries. You have a deterministic tunnel:
screen capture -> visual parser/OCR/YOLO -> state understanding -> planner -> safety -> executor.

Return exactly ONE JSON action. No markdown.

Available actions:
- open_app: {{"action":"open_app","app":"terminal|powershell|cmd|notepad|calculator|explorer|paint|settings|<installed app>"}}
- run_powershell: {{"action":"run_powershell","command":"PowerShell command"}}
- click: {{"action":"click","x":123,"y":456,"button":"left|right","double":false}}
- move: {{"action":"move","x":123,"y":456}}
- drag: {{"action":"drag","fromX":100,"fromY":100,"toX":500,"toY":500,"duration":0.4}}
- type: {{"action":"type","text":"text to type"}}
- hotkey: {{"action":"hotkey","keys":["ctrl","shift","esc"]}}
- press: {{"action":"press","key":"enter"}}
- scroll: {{"action":"scroll","amount":-5}}
- wait: {{"action":"wait","ms":1000}}
- done: {{"action":"done","message":"final user-facing message"}}
- need_user: {{"action":"need_user","message":"ask user for confirmation/manual step"}}

Core rules:
- For Terminal/PowerShell/CMD/opening local apps, use open_app or run_powershell. Do not open Chrome/browser.
- For file operations, prefer safe PowerShell commands over blind clicking.
- For visible UI, click element centers from parser state. Coordinates are screenshot-relative.
- After every action, a new screenshot will be taken. Do not repeat blind actions if state did not change.
- If screen already satisfies the task, return done.
- If delete/overwrite/shutdown/restart/format/uninstall/payment/security/privacy/password/permission elevation is involved and user did not explicitly ask, return need_user.
- If UAC/password/OTP/captcha/security confirmation appears, return need_user.
- Keep final/status message in language mode. Hindi mode means natural Hinglish/Hindi and address user as boss.

Language mode: {language}
User task: {task}
State JSON:
{json.dumps(state, ensure_ascii=False)[:22000]}
"""
    response = model.generate_content(prompt, generation_config={"temperature": 0.1})
    raw = (getattr(response, "text", "") or "").strip()
    return json.loads(strip_json_fence(raw))


def safe_action(task: str, action: dict[str, Any], state: dict[str, Any]) -> tuple[bool, str]:
    text = json.dumps(action, ensure_ascii=False).lower() + " " + task.lower() + " " + str(state.get("visible_text", "")).lower()
    dangerous = [
        "format", "shutdown", "restart", "remove-item", "del ", "rmdir", "erase", "delete",
        "uninstall", "reg delete", "set-executionpolicy", "cipher", "diskpart", "clean",
        "payment", "password", "otp", "uac", "administrator permission"
    ]
    user_explicit = re.search(r"\b(delete|remove|format|shutdown|restart|uninstall|overwrite|admin|administrator)\b", task, re.I)
    if any(word in text for word in dangerous) and not user_explicit:
        return False, "Boss, ye risky system/file action lag raha hai. Confirm karke dobara clearly boliye."
    return True, ""


def run_action(action: dict[str, Any], capture: Capture) -> dict[str, Any]:
    name = str(action.get("action") or "").strip()
    if name == "open_app":
        app = str(action.get("app") or "").strip()
        open_app(app)
        return {"ok": True, "action": "open_app", "app": app}
    if name == "run_powershell":
        command = str(action.get("command") or "").strip()
        if not command:
            raise RuntimeError("PowerShell command missing.")
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            timeout=int(os.environ.get("JARVIS_DESKTOP_SHELL_TIMEOUT", "30")),
        )
        return {"ok": completed.returncode == 0, "action": "run_powershell", "stdout": completed.stdout[-1500:], "stderr": completed.stderr[-1500:]}
    if name == "click":
        x, y = to_screen_xy(action, capture, "x", "y")
        button = str(action.get("button") or "left")
        double = bool(action.get("double", False))
        pyautogui.click(x=x, y=y, button=button, clicks=2 if double else 1, interval=0.08)
        return {"ok": True, "action": "click", "x": x, "y": y, "button": button}
    if name == "move":
        x, y = to_screen_xy(action, capture, "x", "y")
        pyautogui.moveTo(x, y, duration=0.15)
        return {"ok": True, "action": "move", "x": x, "y": y}
    if name == "drag":
        start_x, start_y = to_screen_xy(action, capture, "fromX", "fromY")
        end_x, end_y = to_screen_xy(action, capture, "toX", "toY")
        pyautogui.moveTo(start_x, start_y, duration=0.1)
        pyautogui.dragTo(end_x, end_y, duration=float(action.get("duration", 0.4)), button="left")
        return {"ok": True, "action": "drag", "from": [start_x, start_y], "to": [end_x, end_y]}
    if name == "type":
        text = str(action.get("text") or "")
        set_clipboard(text)
        pyautogui.hotkey("ctrl", "v")
        return {"ok": True, "action": "type", "chars": len(text)}
    if name == "hotkey":
        keys = action.get("keys")
        if not isinstance(keys, list) or not keys:
            raise RuntimeError("hotkey keys missing.")
        pyautogui.hotkey(*[str(key).lower() for key in keys])
        return {"ok": True, "action": "hotkey", "keys": keys}
    if name == "press":
        key = str(action.get("key") or "")
        if not key:
            raise RuntimeError("press key missing.")
        pyautogui.press(key.lower())
        return {"ok": True, "action": "press", "key": key}
    if name == "scroll":
        amount = int(action.get("amount", 0))
        pyautogui.scroll(amount)
        return {"ok": True, "action": "scroll", "amount": amount}
    if name == "wait":
        ms = int(action.get("ms", 1000))
        time.sleep(max(0, min(ms, 30000)) / 1000)
        return {"ok": True, "action": "wait", "ms": ms}
    if name in {"done", "need_user"}:
        return {"ok": True, "action": name, "message": str(action.get("message") or "")}
    raise RuntimeError(f"Unknown Jarvis desktop action: {name}")


def to_screen_xy(action: dict[str, Any], capture: Capture, x_key: str, y_key: str) -> tuple[int, int]:
    x = int(action.get(x_key))
    y = int(action.get(y_key))
    return capture.bounds["left"] + x, capture.bounds["top"] + y


def open_app(app: str) -> None:
    normalized = app.lower().strip()
    commands = {
        "terminal": "wt.exe",
        "windows terminal": "wt.exe",
        "powershell": "powershell.exe",
        "cmd": "cmd.exe",
        "command prompt": "cmd.exe",
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "explorer": "explorer.exe",
        "file explorer": "explorer.exe",
        "paint": "mspaint.exe",
        "settings": "ms-settings:",
    }
    command = commands.get(normalized, app)
    if command.endswith(":"):
        subprocess.Popen(["cmd.exe", "/c", "start", "", command], shell=False)
    else:
        subprocess.Popen(command, shell=True)
    time.sleep(1.2)


def set_clipboard(text: str) -> None:
    script = "$input | Set-Clipboard"
    subprocess.run(["powershell.exe", "-NoProfile", "-Command", script], input=text, text=True, timeout=10)


def invoke(task: str, max_steps: int) -> dict[str, Any]:
    language = "hi" if os.environ.get("JARVIS_LANGUAGE", "hi").lower().startswith("hi") else "en"
    direct_app = detect_direct_app_open(task)
    if direct_app:
        open_app(direct_app)
        memory = load_memory()
        memory["last_task"] = task
        memory["last_app"] = direct_app
        save_memory(memory)
        message = f"{direct_app} khol diya boss." if language == "hi" else f"Opened {direct_app}, boss."
        return final(True, "manual-direct", [{
            "step": 1,
            "planned": {"action": "open_app", "app": direct_app},
            "result": {"ok": True, "action": "open_app", "app": direct_app}
        }], message, memory)

    model, model_name = make_model()
    history: list[dict[str, Any]] = []
    memory = load_memory()
    memory["last_task"] = task

    for step in range(1, max_steps + 1):
        capture = capture_screen()
        parsed = parse_screen(capture.base64_png)
        state = build_state(capture, parsed, history, memory)
        planned = plan_action(model, task, state, language)
        safe, reason = safe_action(task, planned, state)
        if not safe:
            return final(False, model_name, history, reason, memory)
        result = run_action(planned, capture)
        history.append({"step": step, "state": {"active_window": capture.active_window, "bounds": capture.bounds}, "planned": planned, "result": result})
        memory["last_app"] = capture.active_window.get("process", memory.get("last_app", ""))
        save_memory(memory)
        if result.get("action") == "done":
            return final(True, model_name, history, str(result.get("message") or done_message(language)), memory)
        if result.get("action") == "need_user":
            return final(False, model_name, history, str(result.get("message") or "Need user action."), memory)
        if repeated_action_loop(history):
            return final(False, model_name, history, "Boss, main same action loop me fas rahi hoon. Screen state clear nahi badal rahi, is task ko thoda specific boliye.", memory)
        time.sleep(float(os.environ.get("JARVIS_DESKTOP_OBSERVE_DELAY", "0.6")))

    return final(False, model_name, history, "Boss, step limit aa gayi. Is task ko chhote parts me boliye.", memory)


def repeated_action_loop(history: list[dict[str, Any]]) -> bool:
    if len(history) < 4:
        return False
    actions = [json.dumps(item.get("planned", {}), sort_keys=True) for item in history[-4:]]
    return len(set(actions)) <= 1


def detect_direct_app_open(task: str) -> str:
    text = task.lower()
    wants_open = re.search(r"\b(open|launch|start|run|khol|kholo|chala|chalao|call)\b", text, re.I) or re.search(r"(खोल|खोलो|चला|चलाओ|कॉल|ओपन)", task)
    if not wants_open:
        return ""
    app_patterns = [
        ("terminal", [r"\bterminal\b", r"टर्मिनल"]),
        ("powershell", [r"\bpowershell\b", r"पावरशेल"]),
        ("cmd", [r"\bcmd\b", r"\bcommand prompt\b", r"कमांड"]),
        ("notepad", [r"\bnotepad\b", r"नोटपैड"]),
        ("calculator", [r"\bcalculator\b", r"\bcalc\b", r"कैलकुलेटर"]),
        ("explorer", [r"\bfile explorer\b", r"\bexplorer\b", r"फाइल", r"फ़ाइल", r"फोल्डर", r"फ़ोल्डर"]),
        ("settings", [r"\bsettings\b", r"\bsetting\b", r"सेटिंग"]),
        ("paint", [r"\bpaint\b", r"पेंट"]),
    ]
    for app, patterns in app_patterns:
        if any(re.search(pattern, text, re.I) or re.search(pattern, task) for pattern in patterns):
            return app
    return ""


def final(success: bool, model: str, history: list[dict[str, Any]], message: str, memory: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": success,
        "engine": "jarvis-windows-control",
        "provider": "gemini",
        "model": model,
        "done": success,
        "successful": success,
        "steps": len(history),
        "finalResult": message,
        "actions": [item["planned"].get("action") for item in history if isinstance(item.get("planned"), dict)],
        "history": history[-5:],
        "memory": {"last_app": memory.get("last_app"), "last_task": memory.get("last_task")},
    }


def make_model() -> tuple[Any, str]:
    import google.generativeai as genai

    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY missing hai.")
    genai.configure(api_key=api_key)
    model_name = os.environ.get("JARVIS_DESKTOP_MODEL") or os.environ.get("GEMINI_MODEL") or "gemini-2.5-flash-lite"
    return genai.GenerativeModel(model_name), model_name


def done_message(language: str) -> str:
    return "Ho gaya boss, kaam complete kar diya." if language == "hi" else "Done boss, task completed."


def strip_json_fence(text: str) -> str:
    text = re.sub(r"^```json\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"^```\s*", "", text.strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text.strip())
    return text.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Jarvis desktop-control runner")
    parser.add_argument("--task", required=True)
    parser.add_argument("--max-steps", type=int, default=int(os.environ.get("JARVIS_DESKTOP_MAX_STEPS", os.environ.get("JARVIS_WINDOWS_USE_MAX_STEPS", "25"))))
    args = parser.parse_args()
    try:
        result = invoke(args.task, args.max_steps)
    except Exception as error:
        return _json_error(str(error), details=type(error).__name__)
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
